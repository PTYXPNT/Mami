const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. 5K > Akses Fitur ViP
-Rp. 10K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_wa.me/1831353-5216 atau ketik *${prefix}owner*`
}
exports.daftarvip = daftarvip
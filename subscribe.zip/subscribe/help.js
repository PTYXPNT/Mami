const help = (prefix) => { 
	return `

    ╭────COMANDOS──────
    ║╭─────────────────
    ║╠➣  *MAMIBOT*
    ║╰───────────────── 
    ║╭───〘 *INFO*  〙─────
    ║╠-❥ *MAMI BOT* *Versi 9.9*
    ║╠-❥ *Owner : TANPA NAMA*
    ║╠-❥ *Link* : wa.me/18313535216
    ║╠--❥ *Prefix : 「 ${prefix} 」*
    ║╠-❥ *Total Pengguna : 9999*   
    ║╰────────────────
    ║╭───LIST MENU──
    ║╠➣ *${prefix}ownermenu*
    ║╠➣ *${prefix}adminmenu*
    ║╠➣ *${prefix}groupmenu*
    ║╠➣ *${prefix}makermenu*
    ║╠➣ *${prefix}nsfwmenu*
    ║╠➣ *${prefix}listmenu*
    ║╠➣ *${prefix}funmenu*
    ║╠➣ *${prefix}mediamenu*
    ║╠➣ *${prefix}animemenu*
    ║╠➣ *${prefix}kerangmenu*
    ║╠➣ *${prefix}quotemaker*
    ║╠➣ *${prefix}vipmenu*
    ║╠➣ *${prefix}othermenu*
    ║╰───────────────
    ║╭─────OTHER────
    ║╠➣ *${prefix}bugreport*
    ║╠➣ *${prefix}info*
    ║╠➣ *${prefix}owner*
    ║╠➣ *${prefix}request*
    ║╠➣ *${prefix}setprefix*
    ║╠➣ *${prefix}listblock*
    ║╠➣ *${prefix}iklan*
    ║╠➣ *${prefix}runtume*
    ║╠➣ *${prefix}rules*
    ║╠➣ *${prefix}tnc*
    ║╠➣ *${prefix}cekvip*
    ║╠➣ *${prefix}daftarvip*
    ║╠➣ *${prefix}addvip*
    ║╠➣ *${prefix}dellvip*
    ║╠➣ *${prefix}snk*
    ║╠➣ *${prefix}listpremium*
    ║╠➣ *${prefix}donate*
    ║╠➣ *${prefix}fitnah*
    ║╠➣ *${prefix}totaluser*
    ║╠➣ *${prefix}level*
    ║╠➣ *${prefix}leveling*
    ║╠➣ *${prefix}addbacot*
    ║╠➣ *${prefix}bacotlist*
    ║╠➣ *${prefix}resetbacot*
    ║╠➣ *${prefix}glass*
    ║╰─────────────────
    ║╭─────CONTATO─────
    ║╠➣ Name : *Mℛ ᭄KINGツ*
    ║╠➣Coded using *Nano* on Android
    ║║Termux
    ║╠➣ Request? 
    ║╠➣wa.me/18313535216
    ║╠════
    ║║Advanced:
    ║║> return m
    ║╰─────────────────
    ║
    ┗━┅┄┄⟞⟦ *NEL-BOT* ⟧┄┉┉━┛`
}
exports.help = help
